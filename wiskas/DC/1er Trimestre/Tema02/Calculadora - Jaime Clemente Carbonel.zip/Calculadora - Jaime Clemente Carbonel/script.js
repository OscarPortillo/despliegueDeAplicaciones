var solucion; //es el resultado de la operacion.
        var num = 0; //es el primer numero introducido o el almacenamiento de los resultados.
        var num1 = 0; //es el segundo o siguiente numero que se introduce.
        var operacion = ""; //operacion que se va a hacer.
        var pantalla = ""; //lo que se va a ir mostrando en la pantalla de la calculadora.


        function actualizarPantalla() {
            document.getElementById("sol").innerHTML = pantalla;
        }
        function c(){
            num="";
            num1="";
            pantalla="";
            operacion="";
            pantalla="";
            
            actualizarPantalla();
        }

        function sumar() {
            operacion = "+";
            num1 = num;
            num = 0;
            pantalla = pantalla + " + ";

            actualizarPantalla();
        }

        function restar() {
            operacion = "-";
            num1 = num;
            num = 0;
            pantalla = pantalla + " - ";

            actualizarPantalla();
        }

        function multiplicar() {
            operacion = "*";
            num1 = num;
            num = 0;
            pantalla = pantalla + " * ";

            actualizarPantalla();
        }

        function dividir() {
            operacion = "/";
            num1 = num;
            num = 0;
            pantalla = pantalla + " / ";

            actualizarPantalla();
        }

        function igual() {
            switch (operacion) {
                case "+":
                    solucion = parseFloat(num1) + parseFloat(num);
                    break;
                case "-":
                    solucion = parseFloat(num1) - parseFloat(num);
                    break;
                case "*":
                    solucion = parseFloat(num1) * parseFloat(num);
                    break;
                case "/":
                    solucion = parseFloat(num1) / parseFloat(num);
                    break;
            }
            num=solucion;
            pantalla = pantalla + "= " + solucion;
            actualizarPantalla();
        }

        function uno() {
            num = num + "1";
            pantalla = pantalla + "1";

            actualizarPantalla();

        }

        function dos() {
            num = num + "2";
            pantalla = pantalla + "2";

            actualizarPantalla();
        }

        function tres() {
            num = num + "3";
            pantalla = pantalla + "3";

            actualizarPantalla();
        }

        function cuatro() {
            num = num + "4";
            pantalla = pantalla + "4";

            actualizarPantalla();
        }

        function cinco() {
            num = num + "5";
            pantalla = pantalla + "5";

            actualizarPantalla();
        }

        function seis() {
            num = num + "6";
            pantalla = pantalla + "6";

            actualizarPantalla();
        }

        function siete() {
            num = num + "7";
            pantalla = pantalla + "7";

            actualizarPantalla();
        }

        function ocho() {
            num = num + "8";
            pantalla = pantalla + "8";

            actualizarPantalla();
        }

        function nueve() {
            num = num + "9";
            pantalla = pantalla + "9";

            actualizarPantalla();
        }

        function cero() {
            num = num + "0";
            pantalla = pantalla + "0";

            actualizarPantalla();
        }

        function coma() {
            num = num + ".";
            pantalla = pantalla + ",";

            actualizarPantalla();
        }