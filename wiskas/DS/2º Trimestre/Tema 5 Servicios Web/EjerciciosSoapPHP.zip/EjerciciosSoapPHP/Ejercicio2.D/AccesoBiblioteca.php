<?php

/** @class AccesoBiblioteca 
 * 
 * Ejemplo para generación automática del documento WSDL
 */
class AccesoBiblioteca {

    /** función ContarLibros
     * 
     * @param string $autor
     * @return string
     */
    function ContarLibros($autor) {
        try {
            // Crear la conexión con la base de datos MySQL.
            $server = "localhost:3306";
            $user = "root";
            $password = "";
            $database = "biblioteca";
            $conn = new PDO("mysql:host=$server;dbname=$database", $user, $password);
            // Indicar que el modo de tratamiento de errores sea mediante excepciones.
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // Construir la sentencia SQL de obtención de todos los libros de un autor
            // usando un parámetro con nombre.
            $sql = "SELECT * FROM libros WHERE autor = '$autor'";
            $result = $conn->query($sql);
            $numeroLibros = $result->rowCount();
            return $numeroLibros . "<br/>";
        } catch (Exception $ex) {
            return "Error en la Consulta: " . $ex->getMessage() . "<br/>";
        }
        // Cerrar la conexión con MySQL.
        $conn = null;
    }

    /** función ConsultarNombreSocio
     * 
     * @param int $codigo
     * @return string
     */
    function ConsultarNombreSocio($codigo) {
        try {
            // Crear la conexión con la base de datos MySQL.
            $server = "localhost:3306";
            $user = "root";
            $password = "";
            $database = "biblioteca";
            $conn = new PDO("mysql:host=$server;dbname=$database", $user, $password);
            // Indicar que el modo de tratamiento de errores sea mediante excepciones.
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // Construir la sentencia SQL de obtención de todos los libros de un autor
            // usando un parámetro con nombre.
            $sql = "SELECT * FROM socios WHERE codigo = $codigo";
            $result = $conn->query($sql);
            $row = $result->fetch();
            $nombreSocio=$row["nombre"];
            return $nombreSocio . " <br/>";
        } catch (Exception $ex) {
            return "Error en la Consulta: " . $ex->getMessage() . "<br/>";
        }
        // Cerrar la conexión con MySQL.
        $conn = null;
    }

}
