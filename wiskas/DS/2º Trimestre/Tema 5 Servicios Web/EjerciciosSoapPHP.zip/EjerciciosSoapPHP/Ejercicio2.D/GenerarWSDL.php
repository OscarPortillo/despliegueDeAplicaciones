<?php

require_once 'AccesoBiblioteca.php';
require_once 'WSDLDocument.php';
$wsdl = new WSDLDocument( 
    'AccesoBiblioteca', 
    'http://localhost/EjerciciosSoapPHP/Ejercicio2.D/Servidor.php', 
    'http://localhost/EjerciciosSoapPHP/Ejercicio2.D'
); 
echo $wsdl->save('AccesoBiblioteca.wsdl');
