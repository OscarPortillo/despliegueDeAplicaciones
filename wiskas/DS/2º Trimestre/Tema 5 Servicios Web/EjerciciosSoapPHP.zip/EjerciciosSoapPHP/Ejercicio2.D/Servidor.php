<?php

require_once 'AccesoBiblioteca.php';
$wsdl = 'http://localhost/EjerciciosSoapPHP/Ejercicio2.D/AccesoBiblioteca.wsdl';
$server = new SoapServer($wsdl);
$server->setClass('AccesoBiblioteca');
$server->handle();
