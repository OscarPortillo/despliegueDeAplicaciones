<?php

$wsdl = 'http://localhost/EjerciciosSoapPHP/Ejercicio2.D/AccesoBiblioteca.wsdl';
$client = new SoapClient($wsdl);
echo 'Libros escritos por J. R. R. Tolkien: ' . $client->ContarLibros("J. R. R. Tolkien") . '<br/>';
echo 'Nombre del socio con id 1: ' . $client->ConsultarNombreSocio("1") . '<br/>';