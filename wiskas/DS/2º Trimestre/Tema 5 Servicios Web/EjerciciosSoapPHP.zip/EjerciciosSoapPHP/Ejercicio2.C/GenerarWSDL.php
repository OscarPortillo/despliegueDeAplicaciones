<?php

require_once 'AccesoBiblioteca.php';
require_once 'WSDLDocument.php';
$wsdl = new WSDLDocument( 
    'AccesoBiblioteca', 
    'http://localhost/EjerciciosSoapPHP/Ejercicio2.C/Servidor.php', 
    'http://localhost/EjerciciosSoapPHP/Ejercicio2.C'
); 
echo $wsdl->save('AccesoBiblioteca.wsdl');
