<?php

require_once 'AccesoBiblioteca.php';
require_once 'WSDLDocument.php';
$wsdl = new WSDLDocument( 
    'AccesoBiblioteca', 
    'http://localhost/EjerciciosSoapPHP/Ejercicio2.B/Servidor.php', 
    'http://localhost/EjerciciosSoapPHP/Ejercicio2.B'
); 
echo $wsdl->save('AccesoBiblioteca.wsdl');
