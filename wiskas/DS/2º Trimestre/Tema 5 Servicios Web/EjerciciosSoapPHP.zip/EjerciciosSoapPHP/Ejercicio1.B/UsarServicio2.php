<?php
if (isset($_POST["boton"])) {
    $valor = $_POST['valor'];
    $de = $_POST['de'];
    $a = $_POST['a'];

    echo "Valor Introducido: " . $valor . ", de: " . $de . ", a: " . $a . "<br />";
    
    require_once 'ComputerUnit.php';
	$params = new ChangeComputerUnit();
	$params->ComputerValue = $valor;
	$params->fromComputerUnit = $de;
	$params->toComputerUnit = $a;
	$client = new ComputerUnit();
	$response = $client->ChangeComputerUnit($params);
        print_r($response->ChangeComputerUnitResult);
	//var_dump($response);
	echo '<br/>';
    
}
?>
<html
    <head>

    <body>

        <form action = "" method = "post">
            Valor: <input type = "number" name = "valor" /><br>
            De: <select name="de">    
                <option value="Bit" selected="selected">Bit</option>
                <option value="Byte">Byte</option>
                <option value="Kilobyte">Kilobyte</option>
                <option value="Megabyte">Megabyte</option>
                <option value="Gigabyte">Gigabyte</option>
                <option value="Terabyte">Terabyte</option>
                <option value="Petabyte">Petabyte</option>
            </select><br>
            A: <select name="a">    
                <option value="Bit">Bit</option>
                <option value="Byte">Byte</option>
                <option value="Kilobyte">Kilobyte</option>
                <option value="Megabyte">Megabyte</option>
                <option value="Gigabyte">Gigabyte</option>
                <option value="Terabyte">Terabyte</option>
                <option value="Petabyte">Petabyte</option>
            </select><br>
            <input type = "submit" name="boton" />
        </form>
    </body>
</html>