This is a Demo Site for DropPages.com
=====================================

It contains a variety of dummy content, designed as examples of what you can do.

The Content folder is, as you'd expect, the content of the site. Pages.

The Public folder is for static content, like CSS files, Javascript or images.

The Templates folder is for HTML templates.