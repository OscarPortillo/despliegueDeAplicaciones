package search;

// Utility with static method to build a URL for any of the most popular search engines.
public class SearchUtilities {
    
    private static SearchSpec[] commonSpecs = { 
	new SearchSpec("Google", "https://www.google.es/search?q="),
	new SearchSpec("Bing", "https://www.bing.com/search?q="),
	new SearchSpec("Yahoo", "https://es.search.yahoo.com/search?p="),
	new SearchSpec("Baidu", "http://www.baidu.com/s?wd="),
	new SearchSpec("Ask", "https://es.ask.com/web?q="),
	new SearchSpec("Aol", "http://search.aol.com/aol/search?q="),
	new SearchSpec("DuckDuckGo", "https://duckduckgo.com/?q="),
	new SearchSpec("WolframAlpha", "http://www.wolframalpha.com/input/?i="),
	new SearchSpec("Yandex", "https://www.yandex.com/search/?text="),
    };
  
    public static SearchSpec[] getCommonSpecs() {
	return (commonSpecs);
    }

    // Given a search engine name and a search string, builds a URL for the results page of 
    // that search engine for that query. Returns null if the search engine name is not one of 
    // the ones it knows about.
    public static String makeURL(String searchEngineName, String searchString) {
	SearchSpec[] searchSpecs = getCommonSpecs();
	String searchURL = null;
	for (int i = 0; i < searchSpecs.length; i++) {
	    SearchSpec spec = searchSpecs[i];
	    if (spec.getName().equalsIgnoreCase(searchEngineName)) {
		searchURL = spec.makeURL(searchString);
		break;
	    }
	}
	return (searchURL);
    }
    
} // End of SearchUtilities
