<?php
class ChangeComputerUnit {
  public $ComputerValue; // double
  public $fromComputerUnit; // Computers
  public $toComputerUnit; // Computers
}

class Computers {
  const Bit = 'Bit';
  const Byte = 'Byte';
  const Kilobyte = 'Kilobyte';
  const Megabyte = 'Megabyte';
  const Gigabyte = 'Gigabyte';
  const Terabyte = 'Terabyte';
  const Petabyte = 'Petabyte';
}

class ChangeComputerUnitResponse {
  public $ChangeComputerUnitResult; // double
}


/**
 * ComputerUnit class
 * 
 *  
 * 
 * @author    {author}
 * @copyright {copyright}
 * @package   {package}
 */
class ComputerUnit extends SoapClient {

  private static $classmap = array(
                                    'ChangeComputerUnit' => 'ChangeComputerUnit',
                                    'Computers' => 'Computers',
                                    'ChangeComputerUnitResponse' => 'ChangeComputerUnitResponse',
                                   );

  public function ComputerUnit($wsdl = "http://www.webservicex.net/ConvertComputer.asmx?WSDL", $options = array()) {
    foreach(self::$classmap as $key => $value) {
      if(!isset($options['classmap'][$key])) {
        $options['classmap'][$key] = $value;
      }
    }
    parent::__construct($wsdl, $options);
  }

  /**
   *  
   *
   * @param ChangeComputerUnit $parameters
   * @return ChangeComputerUnitResponse
   */
  public function ChangeComputerUnit(ChangeComputerUnit $parameters) {
    return $this->__soapCall('ChangeComputerUnit', array($parameters),       array(
            'uri' => 'http://www.webserviceX.NET/',
            'soapaction' => ''
           )
      );
  }

}

?>
