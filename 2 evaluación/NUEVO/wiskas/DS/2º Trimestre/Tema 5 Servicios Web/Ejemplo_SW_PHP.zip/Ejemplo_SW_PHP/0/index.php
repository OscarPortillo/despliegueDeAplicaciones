<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
	<?php

	// EJEMPLO 1
	$wsdl = 'http://www.webservicex.net/length.asmx?WSDL';
	$client = new SoapClient($wsdl);
	$params = array(
	    'LengthValue' => 30, 
	    'fromLengthUnit' => 'Meters',
	    'toLengthUnit' => 'Feet'
	);
	$response = $client->ChangeLengthUnit($params);
	var_dump($response);
	echo '<br/>';

	// EJEMPLO 2
	require_once 'lengthUnit.php';
	$params = new ChangeLengthUnit();
	$params->LengthValue = 30;
	$params->fromLengthUnit = 'Meters';
	$params->toLengthUnit = 'Feet';
	$client = new lengthUnit();
	$response = $client->ChangeLengthUnit($params);
	var_dump($response);
	echo '<br/>';
	
	// EJEMPLO 3
	$wsdl = 'http://www.webservicex.net/ConvertTemperature.asmx?WSDL';
	$client = new SoapClient($wsdl);
	$params = array(
	    'Temperature' => 30, 
	    'FromUnit' => 'degreeCelsius',
	    'ToUnit' => 'degreeFahrenheit'
	);
	$response = $client->ConvertTemp($params);
	print_r($response);
	echo '<br/>';
	
	// EJEMPLO 4
	require_once 'ConvertTemperature.php';
	$params = new ConvertTemp();
	$params->Temperature = 30;
	$params->FromUnit = 'degreeCelsius';
	$params->ToUnit = 'degreeFahrenheit';
	$client = new ConvertTemperature();
	print_r($client->__getTypes());
	echo '<br/>';
	print_r($client->__getFunctions());
	echo '<br/>';
	$response = $client->ConvertTemp($params);
	print_r($response);
	echo '<br/>';
		
	?>
    </body>
</html>
