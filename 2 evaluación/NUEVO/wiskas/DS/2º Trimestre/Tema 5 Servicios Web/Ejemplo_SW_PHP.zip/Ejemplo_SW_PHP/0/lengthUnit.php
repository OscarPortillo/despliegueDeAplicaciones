<?php
class ChangeLengthUnit {
  public $LengthValue; // double
  public $fromLengthUnit; // Lengths
  public $toLengthUnit; // Lengths
}

class Lengths {
  const Angstroms = 'Angstroms';
  const Nanometers = 'Nanometers';
  const Microinch = 'Microinch';
  const Microns = 'Microns';
  const Mils = 'Mils';
  const Millimeters = 'Millimeters';
  const Centimeters = 'Centimeters';
  const Inches = 'Inches';
  const Links = 'Links';
  const Spans = 'Spans';
  const Feet = 'Feet';
  const Cubits = 'Cubits';
  const Varas = 'Varas';
  const Yards = 'Yards';
  const Meters = 'Meters';
  const Fathoms = 'Fathoms';
  const Rods = 'Rods';
  const Chains = 'Chains';
  const Furlongs = 'Furlongs';
  const Cablelengths = 'Cablelengths';
  const Kilometers = 'Kilometers';
  const Miles = 'Miles';
  const Nauticalmile = 'Nauticalmile';
  const League = 'League';
  const Nauticalleague = 'Nauticalleague';
}

class ChangeLengthUnitResponse {
  public $ChangeLengthUnitResult; // double
}


/**
 * lengthUnit class
 * 
 *  
 * 
 * @author    {author}
 * @copyright {copyright}
 * @package   {package}
 */
class lengthUnit extends SoapClient {

  private static $classmap = array(
                                    'ChangeLengthUnit' => 'ChangeLengthUnit',
                                    'Lengths' => 'Lengths',
                                    'ChangeLengthUnitResponse' => 'ChangeLengthUnitResponse',
                                   );

  public function lengthUnit($wsdl = "http://www.webservicex.net/length.asmx?WSDL", $options = array()) {
    foreach(self::$classmap as $key => $value) {
      if(!isset($options['classmap'][$key])) {
        $options['classmap'][$key] = $value;
      }
    }
    parent::__construct($wsdl, $options);
  }

  /**
   *  
   *
   * @param ChangeLengthUnit $parameters
   * @return ChangeLengthUnitResponse
   */
  public function ChangeLengthUnit(ChangeLengthUnit $parameters) {
    return $this->__soapCall('ChangeLengthUnit', array($parameters),       array(
            'uri' => 'http://www.webserviceX.NET/',
            'soapaction' => ''
           )
      );
  }

}

?>
