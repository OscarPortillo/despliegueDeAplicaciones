<?php

class MyCalculator {
    function sum($a, $b) {
	return $a + $b;
    }
    function substract($a, $b) {
	return $a - $b;
    }
    function multiply($a, $b) {
	return $a * $b;
    }
    function divide($a, $b) {
	return $a / $b;
    }
}

$uri = 'http://localhost/Ejemplo_SW_PHP/1/server1.php';
$options1 = array(
    'uri' => $uri
);
$server = new SoapServer(null, $options1);
$server->setClass('MyCalculator');
$server->handle();
