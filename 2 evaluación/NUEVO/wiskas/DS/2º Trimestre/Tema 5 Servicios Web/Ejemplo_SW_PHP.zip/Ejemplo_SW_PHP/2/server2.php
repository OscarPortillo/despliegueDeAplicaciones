<?php

require_once 'MyCalculator.php';
$wsdl = 'http://localhost/Ejemplo_SW_PHP/2/MyCalculator.wsdl';
$server = new SoapServer($wsdl);
$server->setClass('MyCalculator');
$server->handle();
