<?php

require_once 'MyCalculator.php';
require_once 'WSDLDocument.php';
$wsdl = new WSDLDocument( 
    'MyCalculator', 
    'http://localhost/Ejemplo_SW_PHP/2/server2.php', 
    'http://localhost/Ejemplo_SW_PHP/2'
); 
echo $wsdl->save('MyCalculator.wsdl');
