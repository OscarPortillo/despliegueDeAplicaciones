<?php
class ConvertTemp {
  public $Temperature; // double
  public $FromUnit; // TemperatureUnit
  public $ToUnit; // TemperatureUnit
}

class TemperatureUnit {
  const degreeCelsius = 'degreeCelsius';
  const degreeFahrenheit = 'degreeFahrenheit';
  const degreeRankine = 'degreeRankine';
  const degreeReaumur = 'degreeReaumur';
  const kelvin = 'kelvin';
}

class ConvertTempResponse {
  public $ConvertTempResult; // double
}


/**
 * ConvertTemperature class
 * 
 *  
 * 
 * @author    {author}
 * @copyright {copyright}
 * @package   {package}
 */
class ConvertTemperature extends SoapClient {

  private static $classmap = array(
                                    'ConvertTemp' => 'ConvertTemp',
                                    'TemperatureUnit' => 'TemperatureUnit',
                                    'ConvertTempResponse' => 'ConvertTempResponse',
                                   );

  public function ConvertTemperature($wsdl = "http://www.webservicex.net/ConvertTemperature.asmx?WSDL", $options = array()) {
    foreach(self::$classmap as $key => $value) {
      if(!isset($options['classmap'][$key])) {
        $options['classmap'][$key] = $value;
      }
    }
    parent::__construct($wsdl, $options);
  }

  /**
   *  
   *
   * @param ConvertTemp $parameters
   * @return ConvertTempResponse
   */
  public function ConvertTemp(ConvertTemp $parameters) {
    return $this->__soapCall('ConvertTemp', array($parameters),       array(
            'uri' => 'http://www.webserviceX.NET/',
            'soapaction' => ''
           )
      );
  }

}

?>
