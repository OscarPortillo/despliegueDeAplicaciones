<?php

$wsdl = 'http://localhost/Ejemplo_SW_PHP/2/MyCalculator.wsdl';
$client = new SoapClient($wsdl);
echo 'sum:            10 + 2 = ' . $client->sum(10,2) . '<br/>';
echo 'substraction:   10 - 2 = ' . $client->substract(10,2) . '<br/>';
echo 'multiplication: 10 * 2 = ' . $client->multiply(10,2) . '<br/>';
echo 'division:       10 / 2 = ' . $client->divide(10,2) . '<br/>';
