<?php

$url = 'http://localhost/PhpProject_prueba/server1.php';
$uri = 'http://localhost/PhpProject_prueba';
$options2 = array(
    'location' => $url,
    'uri' => $uri
);
$client = new SoapClient(null, $options2);
echo 'sum:            4+2=' . $client->sum(4, 2) . '<br/>';
echo 'substraction:   4-2=' . $client->substract(4, 2) . '<br/>';
echo 'multiplication: 4*2=' . $client->multiply(4, 2) . '<br/>';
echo 'division:       4/2=' . $client->divide(4, 2) . '<br/>';
