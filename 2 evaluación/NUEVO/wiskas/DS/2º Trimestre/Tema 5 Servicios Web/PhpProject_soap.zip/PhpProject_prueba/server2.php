<?php

require_once 'MyCalculator.php';
$wsdl = 'http://localhost/PhpProject_prueba/MyCalculator.wsdl';
$server = new SoapServer($wsdl);
$server->setClass('MyCalculator');
$server->handle();
