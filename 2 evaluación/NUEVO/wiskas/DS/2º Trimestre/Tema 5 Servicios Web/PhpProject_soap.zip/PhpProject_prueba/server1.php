
<?php

/* @class MyCalculator
 * 
 */

// put your code here
class MyCalculator {
    /* función sumar
     * 
     * @param float $a
     * @param float $b
     * @return float
     */

    function sum($a, $b) {
        return $a + $b;
    }

    /* función restar
     * 
     * @param float $a
     * @param float $b
     * @return float
     */

    function substract($a, $b) {
        return $a - $b;
    }

    /* función multiplicar
     * 
     * @param float $a
     * @param float $b
     * @return float
     */

    function multiply($a, $b) {
        return $a * $b;
    }

    /* función dividir
     * 
     * @param float $a
     * @param float $b
     * @return float
     */

    function divide($a, $b) {
        return $a / $b;
    }

}

$uri = 'http://localhost/PhpProject_prueba/server1.php';
$options1 = array(
    'uri' => $uri
);
$server = new SoapServer(null, $options1);
$server->setClass('MyCalculator');
$server->handle();
