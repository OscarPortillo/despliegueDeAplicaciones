<?php

$wsdl = 'http://localhost/PhpProject_prueba/MyCalculator.wsdl';
$client = new SoapClient($wsdl);
echo 'sum:            4+2=' . $client->sum(4, 2) . '<br/>';
echo 'substraction:   4-2=' . $client->substract(4, 2) . '<br/>';
echo 'multiplication: 4*2=' . $client->multiply(4, 2) . '<br/>';
echo 'division:       4/2=' . $client->divide(4, 2) . '<br/>';

