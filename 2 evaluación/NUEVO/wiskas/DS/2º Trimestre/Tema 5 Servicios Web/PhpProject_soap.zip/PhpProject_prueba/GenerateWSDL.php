<?php

require_once 'MyCalculator.php';
require_once 'WSDLDocument.php';
$wsdl = new WSDLDocument(
        'MyCalculator', 
        'http://localhost/PhpProject_prueba/server2.php', 
        'http://localhost/PhpProject_prueba'
);
echo $wsdl->save('MyCalculator.wsdl');
