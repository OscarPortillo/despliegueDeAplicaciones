var primeroValidado = false;

function funcion1() {
	var nombre = document.getElementById("nombre").value;
	var apellidos = document.getElementById("apellidos").value;
	var email = document.getElementById("email").value;
	var usuario = document.getElementById("usuario").value;
	var dni = document.getElementById("dni").value;

	if (validarTexto(nombre) == true && nombre.length >= 2) {
		if (validarTexto(apellidos) == true && apellidos.length >= 2) {
			if (email.length > 3) {//solo compruebo qe han introducido algun dato, lo valida el html
				if (validarUsuario(usuario) == true && usuario.length >= 2) {
					if (nif(dni)) {
						primeroValidado = true;
						alert("Validacion CORRECTA");
					} else {
						alert("El dni no es válido");
					}
				} else {
					alert("El usuario tiene que contener como minimo 2 letras");
				}
			} else {
				alert("El email no es correcto.");
			}
		} else {
			alert("El apellido solo puede contener letras y como minimo 2");
		}

	} else {
		alert("El nombre solo puede contener letras y como minimo 2");
	}

}

function funcion2() {
	var iban = document.getElementById("iban").value;
	var ccc = document.getElementById("ccc").value;
	var contraseña = document.getElementById("contraseña").value;

	if (primeroValidado == true) {
		if (validarIban(iban) == true) {
			if (validarCcc(ccc) == true) {
				if (contraseña.length > 3) {
					document.fvalida.submit();
				} else {
					alert("La contraseña tiene que tener como minimo 4 caracteres")
				}
			} else {
				alert("El ccc no es válido");
			}
		} else {
			alert("El iban no es válido");
		}
	} else {
		alert("Hay que rellenar y validar los datos anteriores")
	}
}

function validarTexto(texto) {
	var esTexto = true;
	for (i = 0; i < texto.length; i++) {
		var letra = texto.charAt(i);
		if (isNaN(letra) == false) {
			esTexto = false
		}
	}
	return esTexto;
}

function validarUsuario(usuario) {
	esValido = true;
	var numeroLetras = 0;
	for (i = 0; i < usuario.length; i++) {
		var letra = usuario.charAt(i);
		if (isNaN(letra) == true) {
			numeroLetras++;
		}
	}
	if (numeroLetras >= 2) {
		esValido = true;
	} else {
		esValido = false;
	}
	return esValido;
}

function nif(dni) {
	var numero
	var letr
	var letra
	var expresion_regular_dni

	expresion_regular_dni = /^\d{8}[a-zA-Z]$/;

	if (expresion_regular_dni.test(dni) == true) {
		numero = dni.substr(0, dni.length - 1);
		letr = dni.substr(dni.length - 1, 1);
		numero = numero % 23;
		letra = 'TRWAGMYFPDXBNJZSQVHLCKET';
		letra = letra.substring(numero, numero + 1);
		if (letra != letr.toUpperCase()) {
			return false; //alert('Dni erroneo, la letra del NIF no se corresponde');
		} else {
			return true; //alert('Dni correcto');
		}
	} else {
		return false; //alert('Dni erroneo, formato no válido');
	}
}

function validarIban(iban) {
	esValido = true;
	if (iban.length == 4) {
		if (isNaN(iban.charAt(0)) == true) {
			if (isNaN(iban.charAt(1)) == true) {
				if (isNaN(iban.charAt(2)) == false) {
					if (isNaN(iban.charAt(3)) == false) {

					} else {
						esValido = false;
					}
				} else {
					esValido = false;
				}
			} else {
				esValido = false;
			}
		} else {
			esValido = false;
		}
	} else {
		esValido = false;
	}
	return esValido;
}

function validarCcc(ccc) {
	esValido = true;
	for (i = 0; i < ccc.length; i++) {
		var numero = ccc.charAt(i);
		if (isNaN(numero) == true) {
			esValido = false;
		}
	}
	if (ccc.length != 16) {
		esValido = false;
	}
	return esValido;
}
