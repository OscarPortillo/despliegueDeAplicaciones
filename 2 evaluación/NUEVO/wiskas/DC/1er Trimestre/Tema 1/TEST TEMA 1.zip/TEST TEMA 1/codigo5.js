console.log("Hola Mundo!");
var mensaje;
mensaje="Este texto está guardado en una variable";
alert(mensaje);