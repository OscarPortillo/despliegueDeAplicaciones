console.log("Hola Mundo!");
alert("Soy el primer script");