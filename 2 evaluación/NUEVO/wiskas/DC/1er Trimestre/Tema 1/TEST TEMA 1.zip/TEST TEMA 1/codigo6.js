console.log("Hola Mundo!");
var mensaje;
mensaje="Hola Mundo! \n    Qué fácil es incluir \'comillas simples\' \n y \"comillas dobles\"";
alert(mensaje);
