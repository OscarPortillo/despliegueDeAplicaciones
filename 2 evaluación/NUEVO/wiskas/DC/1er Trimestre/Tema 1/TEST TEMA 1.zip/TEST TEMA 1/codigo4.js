console.log("Hola Mundo!");
alert("Visualmente no hay ninguna diferencia en colocar el script en el head o en el body");