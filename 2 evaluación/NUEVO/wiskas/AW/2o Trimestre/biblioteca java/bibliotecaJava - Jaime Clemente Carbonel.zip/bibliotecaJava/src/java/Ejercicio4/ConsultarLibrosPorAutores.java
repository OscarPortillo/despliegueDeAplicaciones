/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio4;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author usuario
 */
public class ConsultarLibrosPorAutores extends HttpServlet {

// JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/biblioteca";

    //  Database credentials
    static final String USER = "root";
    static final String PASS = "";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            out.println("Conexión con base de datos realizada con éxito." + "<br>");
            String sql = "SELECT codigo, titulo, autor, anno, numero_ejemplares FROM libros WHERE autor = ?";
            //out.println(sql + "<br/>");
            // Preparar la sentencia SQL.
            stmt = conn.prepareStatement(sql);
            
            // Extraer los autores de libros y procesar cada autor introducido.
            String autores = request.getParameter("autores");
            String arrayAutores[] = autores.split(",");
            for (String autor : arrayAutores) {
                // Asignar un valor al parámetro definido con el nombre 'autor'.
                stmt.setString(1,autor);
                out.println(sql);
                // Ejecutar la sentencia SQL en MySQL.
                ResultSet rs = stmt.executeQuery(sql);
                // Visualizar los libros del autor devueltos en una tabla HTML.
                
                if (stmt.getMaxRows() > 0) {
                    out.println("<table border=1>");
                    out.println("<tr>");
                    out.println("<th>Código</th>");
                    out.println("<th>Título</th>");
                    out.println("<th>Autor</th>");
                    out.println("<th>Año</th>");
                    out.println("<th>Número de Ejemplares</th>");
                    out.println("</tr>");
                    while (rs.next()) {
                        out.println("<tr>");
                        out.println("<td>" + rs.getInt("codigo") + "</td>");
                        out.println("<td>" + rs.getString("titulo") + "</td>");
                        out.println("<td>" + rs.getString("autor") + "</td>");
                        out.println("<td>" + rs.getInt("anno") + "</td>");
                        out.println("<td>" + rs.getInt("numero_de_ejemplares") + "</td>");
                        out.println("<tr>");
                    }
                    out.println("</table><br/><br/>");
                } else {
                    out.println("No hay libros con el autor " + autor + ".<br/><br/>");
                }
            }

            out.println("</body>");
            out.println("</html>");
        } catch (SQLException se) {
            try {
                conn.rollback();
                out.println("Error");
            } catch (SQLException e) {
            };
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (stmt != null) {
                    conn.close();
                }
            } catch (SQLException se) {
            }// do nothing
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }//end finally try
        }//end try
    }//end main
}//end JDBCExample
