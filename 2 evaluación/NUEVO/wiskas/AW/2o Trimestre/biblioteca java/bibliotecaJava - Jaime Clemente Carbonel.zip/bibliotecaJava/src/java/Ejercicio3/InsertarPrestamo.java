/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio3;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author usuario
 */
public class InsertarPrestamo extends HttpServlet {

// JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/biblioteca";

    //  Database credentials
    static final String USER = "root";
    static final String PASS = "";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Connection conn = null;
        Statement stmt = null;
        try {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Insertar Prestamo</title>");
            out.println("</head>");
            out.println("<body>");
            //--------------------
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            out.println("Conexión con base de datos realizada con éxito." + "<br>");
            //--
            stmt = conn.createStatement();
            conn.setAutoCommit(false);
            boolean todo_bien = true;
            String sql = "SELECT numero_de_ejemplares FROM libros WHERE codigo='" + request.getParameter("codigo_libro") + "'";
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            int librosDisponibles = rs.getInt("numero_de_ejemplares");

            if (librosDisponibles > 0) {
                sql = "INSERT INTO prestamos VALUES (" + request.getParameter("codigo_libro") + ", " + request.getParameter("codigo_socio")
                        + ", '" + request.getParameter("fecha_inicio") + "', '" + request.getParameter("fecha_fin") + "', '0000-00-00')";
                out.println(sql);
                if (stmt.executeUpdate(sql) == 0) {//
                    todo_bien = false;
                }
                sql = "UPDATE libros SET numero_de_ejemplares=" + (librosDisponibles - 1) + " WHERE codigo=" + request.getParameter("codigo_libro");
            
                if (stmt.executeUpdate(sql) == 0) {//
                    todo_bien = false;
                }
                if (todo_bien == true) {
                    conn.commit();
                    out.println("El préstamo se ha hecho correctamente.");
                } else {
                    conn.rollback();
                    out.println("NO se ha podido realizar el préstamo.");
                }

            } else {
                out.println("No quedan ejemplares.");
            }

            //--------------------
            out.println("</body>");
            out.println("</html>");
        } catch (SQLException se) {
            try {
                conn.rollback();
                out.println("Error");
            } catch (SQLException e) {
            };
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (stmt != null) {
                    conn.close();
                }
            } catch (SQLException se) {
            }// do nothing
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }//end finally try
        }//end try
    }//end main
}//end JDBCExample
